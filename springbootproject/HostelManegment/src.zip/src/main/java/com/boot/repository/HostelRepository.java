package com.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.entity.HostelEntity;

public interface HostelRepository extends JpaRepository<HostelEntity, Integer> {

}











